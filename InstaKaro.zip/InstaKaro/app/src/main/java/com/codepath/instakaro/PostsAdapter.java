package com.codepath.instakaro;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.parse.ParseFile;

import java.util.List;

public class PostsAdapter extends RecyclerView.Adapter<PostsAdapter.ViewHolder>{

    private Context context;
    private List<Post> posts;

    public PostsAdapter(Context context, List<Post> posts) {
        this.context = context;
        this.posts = posts;
    }

    @NonNull
    @Override
    //create individual row
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.post_item,parent,false);
        return new ViewHolder(view);
    }

    //bind the data into a viewholder
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Post post = posts.get(position);
        holder.bind(post);
    }

    @Override
    public int getItemCount() {
        return posts.size();
    }

    //one row
    class ViewHolder extends RecyclerView.ViewHolder{

        private TextView tvDescription;
        private ImageView ivPicture;
        private TextView tvHandle;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            ivPicture=itemView.findViewById(R.id.ivPicture);
            tvHandle=itemView.findViewById(R.id.tvHandle);
        }
        public void bind(Post post){
            //TODO: bind UI elemnts to a post
            if(post.getUser()!=null) {
                tvHandle.setText(post.getUser().getUsername());
                tvDescription.setText(post.getDescription());
            }
            ParseFile image = post.getImage();
            if (image!=null)
                Glide.with(context).load(image.getUrl()).into(ivPicture);
            else {
                ivPicture.requestLayout();
                ivPicture.getLayoutParams().height = 0;
            }
        }
    }
}
